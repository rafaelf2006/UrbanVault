<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>UrbanVault</title>
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;600&family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
</head>
<body>
  <header>
    <div class="logo">UrbanVault</div>
    <nav>
      <ul>
        <li><a href="#about">Sobre</a></li>
        <li><a href="loja.php">Loja</a></li>
        <div class="search">
          <input type="text" placeholder="Pesquise..">
        </div>
        <!-- Ícone de usuário -->
        <li class="user-icon">
          <?php if(isset($_SESSION['username'])): ?>
            <a href="logout.php"><img src="imagens/user.png" alt="Logout" class="header-avatar"></a>
          <?php else: ?>
            <a href="login.php"><img src="imagens/user.png" alt="Login" class="header-avatar"></a>
          <?php endif; ?>
        </li>
      </ul>
    </nav>
  </header>

  <section class="hero">
    <div class="overlay"></div>
    <div class="hero-content">
      <h1 class="reveal">Desbloqueia o teu estilo</h1>
      <p class="reveal">Streetwear premium — só os melhores drops.</p>
      <a href="loja.php"><button class="reveal">Shop Now</button></a>
    </div>
  </section>

  <section id="novidades">
    <h2 class="section-title">Novidades</h2>
    <div class="products">

      <!-- Produtos -->
      <div class="product reveal">
        <img src="https://images.unsplash.com/photo-1520975918318-3e58d7ed3694?auto=format&fit=crop&w=800&q=80" alt="">
        <h3>Hoodie UrbanVault</h3>
        <p>€79,99</p>
      </div>

    
      <div class="product reveal">
        <img src="https://images.unsplash.com/photo-1520974735194-56f34a4b1a6f?auto=format&fit=crop&w=800&q=80" alt="">
        <h3>T-shirt Signature</h3>
        <p>€39,99</p>
      </div>

    </div>
  </section>

  <section id="about">
    <h2 class="section-title reveal">Sobre a UrbanVault</h2>
    <p class="about-text reveal">
      A UrbanVault nasceu da cultura de rua e da paixão pelo estilo. Selecionamos apenas os melhores sneakers e roupa streetwear para que possas elevar o teu look todos os dias.  
      Faz parte da comunidade — desbloqueia o teu estilo com a UrbanVault.
    </p>
  </section>

  <footer>
    <p>© 2025 UrbanVault. Todos os direitos reservados.</p>
    <p>Siga-nos em @urbanvault_official</p>
  </footer>

  <script src="script.js"></script>
</body>
</html>
