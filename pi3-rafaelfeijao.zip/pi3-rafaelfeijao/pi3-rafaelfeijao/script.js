// Efeito de scroll suave
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    if (this.getAttribute('href').startsWith('#')) {
      e.preventDefault();
      document.querySelector(this.getAttribute('href')).scrollIntoView({
        behavior: 'smooth'
      });
    }
  });
});

// Scroll Reveal Animation
const reveals = document.querySelectorAll('.reveal');

window.addEventListener('scroll', () => {
  const triggerBottom = window.innerHeight * 0.8;

  reveals.forEach(r => {
    const top = r.getBoundingClientRect().top;
    if (top < triggerBottom) {
      r.classList.add('active');
    }
  });
});
